import java.util.Date;

/**
 * A fix-sized array of students
 * array length should always be equal to the number of stored elements
 * after the element was removed the size of the array should be equal to the number of stored elements
 * after the element was added the size of the array should be equal to the number of stored elements
 * null elements are not allowed to be stored in the array
 * 
 * You may add new methods, fields to this class, but DO NOT RENAME any given class, interface or method
 * DO NOT PUT any classes into packages
 *
 */
public class StudentGroup implements StudentArrayOperation {

	private Student[] students;
	
	/**
	 * DO NOT remove or change this constructor, it will be used during task check
	 * @param length
	 */
	public StudentGroup(int length) {
		this.students = new Student[length];
	}

	@Override
	public Student[] getStudents() {
		return students; 
		//return null;
	}

	@Override
	public void setStudents(Student[] students) {
		
		if((students == null)&&!(students.typeOf(Student)))
		{
			throw IllegalArgumentException;
		}
		else 		{
			
					}
	}

	@Override
	public Student getStudent(int index) {
		if(index<0||index>=students.length)
			throw IllegalArgumentException;
		else
			return students[index];
	}

	@Override
	public void setStudent(Student student, int index) {
		if(index<0||index>=students.length)
		{
			throw IllegalArgumentException;
		}
		else
		{
			students[index] = student;
		}
			
	}

	@Override
	public void addFirst(Student student) {
		
		int n =students.length;
		Student s1[] = new Student[n+1];
		s1[0] =student;
		for(int i=0;i<students.length;i++)
			s1[i+1] = students[i];
		Student student[] = new Student[n+1];
		for(int i=0;i<(students.length+1);i++)
			students[i] = s1[i];	
	}

	@Override
	public void addLast(Student student) {
		  int n = students.length;
		  students[i+1] = student;
	}

	@Override
	public void add(Student student, int index) {
		if(index<0||index>=students.length)
		{
			throw IllegalArgumentException;
		}
		for(int i=0;i<students.length;i++)
		{
			if(i==index)
			{
				students[i] =student;
			}
			if(i>index)
			{
				students[i+1] = students[i];
			}
		}
	}

	@Override
	public void remove(int index) {
		if(index<0||index>=students.length)
		{
			throw IllegalArgumentException;
		}
		for(int i=0;i<students.length;i++)
		{
			if(i==index)
			{
				students[i] =students[i+1];
			}
			if(i>index)
			{
				students[i] =students[i+1];
			}
			
		}
	}

	@Override
	public void remove(Student student) {
		if(students==null){
			throw 
		}
			int b=0;
		for(int i=0;i<students.length;i++)
		{
		
			if(students[i] == student)
			{
				int b =i;

				students[i] =students[i+1];
							break;
			}
			
			else if(i==students.length){
				System.out.println("Student not exist");
			}			
									
			
		}
		for(int j=b+1;j<students.length-1;j++)
			{
				students[j] =students[j+1];
			}
	}

	@Override
	public void removeFromIndex(int index) {
		if(index<0||index>=students.length)
		{
			throw IllegalArgumentException;
		}
		int b=0;
		for(int i=0;i<students.length;i++)
		{
		
			if(i== index)
			{
				int b =i;

				for(int j=b+1;j<students.length-1;j++)
			{
				students[j] =null;
			}
			break;
			}
			
		
						
									
			
		}
		
	}

	@Override
	public void removeFromElement(Student student) {
		for(int i=0;i<students.length;i++)
		{
		
			if(students[i]== student)
			{
				int b =i;

				for(int j=b+1;j<students.length-1;j++)
			{
				students[j] =null;
			}
			break;
			}
			
			else if(i==students.length){
				System.out.println("Student not exist");
			}			
									
			
		}
	}

	@Override
	public void removeToIndex(int index) {
		if(index<0||index>=students.length)
		{
			throw IllegalArgumentException;
		}
		int b=0;
		for(int i=0;i<students.length;i++)
		{
		
			if(i== index)
			{
				int b =i;

				for(int j=b;j>=0;j--)
			{
				students[j] ="";
			}
			
			int l=0;
			for(int k=b;k<st.length;k++)
			{	
				students[l] =students[k+1];
				l++;
			}
			break;
			}
			
		
						
									
			
		}
	}

	@Override
	public void removeToElement(Student student) {
		for(int i=0;i<students.length;i++)
		{
		
			if(students[i] == student)
			{
				int b =i;
				int k=b;
				for(int j=b;j>=0;j--)
			{	
				students[j] ="";
				
			}
			int l=0;
			for(int k=b;k<st.length;k++)
			{	
				students[l] =students[k+1];
				l++;
			}
			break;
			}
			
			else if(i==students.length){
				System.out.println("Student not exist");
			}			
									
			
		}	}

	@Override
	public void bubbleSort() {
		int t=0,i=0,j=0;
		int a[] =new int[students.length];
		for(i=0;i<students.length;i++)
		{
			a[i] = students[i].id;
		}
		int n=students.length;
	boolean swap = false;;
	
			for(i=0;i<n-1;i++)
			{
				
				for(j=0;j<n-i-1;j++)
				{
					if(a[j] > a[j+1])
					{
						t =a[j];
						a[j] =a[j+1];
						a[j+1] = t;
					}
					
				}
			}
	
		
	@Override
	public Student[] getByBirthDate(Date date) {
		// Add your implementation here
		return null;
	}

	@Override
	public Student[] getBetweenBirthDates(Date firstDate, Date lastDate) {
		// Add your implementation here
		return null;
	}

	@Override
	public Student[] getNearBirthDate(Date date, int days) {
		// Add your implementation here
		return null;
	}

	@Override
	public int getCurrentAgeByDate(int indexOfStudent) {
		// Add your implementation here
		return 0;
	}

	@Override
	public Student[] getStudentsByAge(int age) {
		// Add your implementation here
		return null;
	}

	@Override
	public Student[] getStudentsWithMaxAvgMark() {
		// Add your implementation here
		return null;
	}

	@Override
	public Student getNextStudent(Student student) {
		ListIterator<Student> li=  students.listIterater();
		if(li.hasNext())
		return li.next();
	else
		return null;
	}
}
